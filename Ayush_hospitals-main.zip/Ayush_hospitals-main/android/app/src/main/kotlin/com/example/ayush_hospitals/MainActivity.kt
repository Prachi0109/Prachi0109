package com.example.ayush_hospitals

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
