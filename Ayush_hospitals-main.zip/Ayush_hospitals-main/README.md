<<<<<<< HEAD
# Ayush Hospitals

This application can be used to search ayushman hospitals, it will help user to search hospitals near their location and as well as in their state or district. This project also has the feature to find optimal route of hospital from the user's current location. You can also see the hospital details for the extra information.

## Technology Used

- (Dart) Flutter Development
- Google map API
- TomTom route finding API
- Sql (Mysql)
