import 'package:flutter/cupertino.dart';

class Scans {
  static List<Image> images = [
    Image.asset('lib/assets/images/scan1.png'),
    Image.asset('lib/assets/images/scan2.png'),
    Image.asset('lib/assets/images/scan3.png'),
    Image.asset('lib/assets/images/scan4.png'),
  ];
}
